import React from 'react'
import HaberListesi from '../haberListesi/page'

function page() {
  return (
    <div>
    <HaberListesi kategori={"Önerilen"}/>
    </div>
  )
}

export default page