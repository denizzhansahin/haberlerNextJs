import React from 'react'
import HaberListesi from '../haberListesi/page'


function page() {
  return (
    <div>
    <HaberListesi/>
    </div>
  )
}

export default page